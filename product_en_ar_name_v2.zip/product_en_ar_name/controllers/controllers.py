# -*- coding: utf-8 -*-
# from odoo import http


# class ProuductEnArName(http.Controller):
#     @http.route('/prouduct_en_ar_name/prouduct_en_ar_name', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/prouduct_en_ar_name/prouduct_en_ar_name/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('prouduct_en_ar_name.listing', {
#             'root': '/prouduct_en_ar_name/prouduct_en_ar_name',
#             'objects': http.request.env['prouduct_en_ar_name.prouduct_en_ar_name'].search([]),
#         })

#     @http.route('/prouduct_en_ar_name/prouduct_en_ar_name/objects/<model("prouduct_en_ar_name.prouduct_en_ar_name"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('prouduct_en_ar_name.object', {
#             'object': obj
#         })

