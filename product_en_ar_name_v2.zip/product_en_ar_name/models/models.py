# -*- coding: utf-8 -*-

from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class InheritProductTemplate(models.Model):
    _inherit = 'product.template'

    actual_name = fields.Char()
    eng_name = fields.Char()
    name_select = fields.Selection([('ar', 'Arabic'), ('en', 'English')], default='ar')

    @api.model
    def create(self, values):
        values['actual_name'] = values.get('name')
        return super(InheritProductTemplate, self).create(values)

    def write(self, values):
        if 'name' in values.keys() and values.get('name') != self.actual_name and values.get('name') != self.eng_name:
            name_select = values.get('name_select', self.name_select)
            if not name_select or name_select == 'ar':
                values['actual_name'] = values.get('name')
            elif name_select == 'en':
                values['eng_name'] = values.get('name')
        return super(InheritProductTemplate, self).write(values)

    @api.onchange('name_select')
    def onchange_name_select(self):
        if self.eng_name:
            if not self.actual_name and self.name_select == 'en':
                self.actual_name = self.name
            self.name = self.eng_name if self.name_select == 'en' else self.actual_name
