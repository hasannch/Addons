# -*- coding: utf-8 -*-
{
    'name': "Product_en_ar_name",

    'summary': "Name configuration for English and Arabic language.",

    'description': """
Name will change based on a selection either it's an english or arabic language. All over the system name should be updated.
    """,

    'author': "Al-Amin",
    'website': "https://www.outsetx.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
    ]
}

