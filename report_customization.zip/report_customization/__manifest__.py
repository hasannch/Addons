{
    'name': 'Report Customization',
    'version': '17.0',

    "author": "Rao Mubasher Hussain",
    "website": "https://www.linkedin.com/in/rao-mubasher-hussain-a9a40a154?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app",
    'company': '',
    'maintainer': 'Rao Mubasher Hussain',

    'depends': ['base', 'sale', 'account'],
    'license': 'LGPL-3',
    'category': 'Productivity',

    'summary': """ Report Customization, Add background/cover image """,
    'description': """ Report Customization, Add background/cover image """,

    'data': [

        'report/external_layout_boxed.xml',
        'report/sale_order_template.xml',
        'report/invoice_template_inherit.xml',
        'report/reports.xml',

    ],

    'installable': True,
    'application': True,
    'auto_install': False,
    'images': ['static/description/image/eco_ng_header.png'],

}
