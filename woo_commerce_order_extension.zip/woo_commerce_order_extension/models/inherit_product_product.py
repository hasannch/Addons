from odoo import fields, models, api


class InheritProductProduct(models.Model):
    _inherit = 'product.product'

    alter_product_id = fields.Many2one('product.product', tracking=True, domain="[('product_tmpl_id', '=', product_tmpl_id), ('active', '=', True)]")
    alter_qty = fields.Float(tracking=True)
