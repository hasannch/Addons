# -*- coding: utf-8 -*-

from . import inherit_sale_order, inherit_product_product
