# -*- coding: utf-8 -*-

from odoo import models, fields, api
import logging

_logger = logging.getLogger("WooCommerce")


class InheritWooSaleOrder(models.Model):
    _inherit = "sale.order"

    @api.model
    def create_woo_order_line(self, line_id, product, quantity, price, taxes, tax_included, woo_instance, is_shipping=False):
        if product.alter_product_id and product.alter_qty > 0:
            quantity *= product.alter_qty
            price /= product.alter_qty
            product = product.alter_product_id
        return super(InheritWooSaleOrder, self).create_woo_order_line(line_id=line_id, product=product, quantity=quantity, price=price, taxes=taxes, tax_included=tax_included, woo_instance=woo_instance, is_shipping=is_shipping)
