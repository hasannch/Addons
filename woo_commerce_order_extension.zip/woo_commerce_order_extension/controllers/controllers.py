# -*- coding: utf-8 -*-
# from odoo import http


# class WooCommerceOrderExtension(http.Controller):
#     @http.route('/woo_commerce_order_extension/woo_commerce_order_extension', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/woo_commerce_order_extension/woo_commerce_order_extension/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('woo_commerce_order_extension.listing', {
#             'root': '/woo_commerce_order_extension/woo_commerce_order_extension',
#             'objects': http.request.env['woo_commerce_order_extension.woo_commerce_order_extension'].search([]),
#         })

#     @http.route('/woo_commerce_order_extension/woo_commerce_order_extension/objects/<model("woo_commerce_order_extension.woo_commerce_order_extension"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('woo_commerce_order_extension.object', {
#             'object': obj
#         })

