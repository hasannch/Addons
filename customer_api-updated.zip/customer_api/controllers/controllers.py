from odoo import http, exceptions
from odoo.http import request
from odoo.exceptions import UserError


class OdooRestful(http.Controller):

    # Customer API......................................

    @http.route(route='/read/customer', type='json', auth='user')
    def read_partners(self, **kwargs):
        user = request.env.user
        partners_sheet = request.env['res.partner'].sudo().search([])
        partners_data = []
        for partners in partners_sheet:
            data = {
                'student_id': partners.student_id,
                'name': partners.name,
                'last_name': partners.last_name,
                'student_department_id': partners.student_department_id,
            }
            partners_data.append(data)
        response = {'status': 200, 'response': partners_data, 'message': 'Success'}
        return response

    @http.route(route='/create/customer', type='json', methods=['POST'], auth='user')
    def create_customer(self, **kwargs):
        create_customer = request.env['res.partner'].search([('is_company', '=', True)])
        student_id = kwargs.get('student_id')
        name = kwargs.get('name')
        last_name = kwargs.get('last_name')
        student_department_id = kwargs.get('student_department_id')

        try:
            # Creating a new customer
            new_customer = create_customer.sudo().create({
                'student_id': student_id,
                'name': name,
                'last_name': last_name,
                'student_department_id': student_department_id,

            })
            return {'success': True, 'message': 'Record created successfully'}
        except exceptions.UserError as e:
            return {'success': False, 'message': str(e)}


# Product APIs.................................................................

    @http.route('/create/product', type='json', auth='user')
    def create_products(self, **kwargs):
        products = request.env['product.template']
        name = kwargs.get('name')
        detailed_type = kwargs.get('detailed_type')
        list_price = kwargs.get('list_price')
        standard_price = kwargs.get('standard_price')
        try:
            new_line = products.sudo().create({
                'name': name,
                'detailed_type': detailed_type,
                'list_price': list_price,
                'standard_price': standard_price,

            })
            return {'success': 200, 'message': 'Record created successfully'}
        except UserError as e:
            return {'success': 500, 'message': str(e)}

    @http.route(route='/read/products', type='json', auth='user')
    def read_products(self, **kwargs):
        products = request.env['product.template'].sudo().search([])
        products_data = []
        for product in products:
            data = {
                'name': product.name,
                'detailed_type': product.detailed_type,
                'list_price': product.list_price,
                'standard_price': product.standard_price,
            }
            products_data.append(data)
        response = {'status': 200, 'response': products_data, 'message': 'Success'}
        return response

    @http.route('/update/product', type='json', auth='user')
    def update_attendance(self, **kwargs):
        product_id = kwargs.get('id')
        products = request.env['product.template']
        try:
            product = products.sudo().browse(product_id)
            if product:
                product.write({
                    'name': kwargs.get('name'),
                    'detailed_type': kwargs.get('detailed_type'),
                    'list_price': kwargs.get('list_price'),
                    'standard_price': kwargs.get('standard_price'),
                })
                return {'success': 200, 'message': 'Record updated successfully'}
            else:
                return {'success': 404, 'message': 'Record not found'}
        except UserError as e:
            return {'success': 500, 'message': str(e)}

    @http.route(route='/delete/product', type='json', auth='user')
    def delete_attendance(self, **kwargs):
        product_id = kwargs.get('id')
        response = {'success': False, 'message': 'Record not found'}
        if product_id:
            products = request.env['product.template'].sudo().search([('id', '=', product_id)])
            if products:
                products.sudo().unlink()
                response = {'success': True, 'message': 'Record has been delete successfully'}
        return response

    # Invoice API............................................................................................

    @http.route('/read/invoices', type='json', auth='user')
    def read_invoices(self, **kwargs):
        invoices = request.env['account.move'].sudo().search([])
        invoices_data = []
        for invoice in invoices:
            invoice_lines_data = []
            for line in invoice.invoice_line_ids:
                line_data = {
                    'product': line.product_id.name,
                    'quantity': line.quantity,
                    'price_unit': line.price_unit,
                    'subtotal': line.quantity * line.price_unit,
                }
                invoice_lines_data.append(line_data)
            invoice_data = {
                'name': invoice.number,
                'date': invoice.date_invoice,
                'partner': invoice.partner_id.name,
                'invoice_date': invoice.invoice_date,
                'lines': invoice_lines_data,
            }
            invoices_data.append(invoice_data)
        response = {'status': 200, 'response': invoices_data, 'message': 'Success'}
        return response


    @http.route('/create/invoice', type='json', auth='user')
    def create_invoice(self, **kwargs):
        invoice_data = {
            'partner_id': kwargs.get('partner_id'),
            'invoice_date': kwargs.get('invoice_date'),
            'move_type': 'out_invoice',
        }
        invoice_lines = []
        try:
            for line in kwargs.get('invoice_lines', []):
                invoice_lines.append((0, 0, {
                    'product_id': line.get('product_id'),
                    'quantity': line.get('unit_amount'),
                    'price_unit': line.get('product_charge'),
                    'subtotal': line.get('subtotal'),
                }))
            invoice_data['invoice_line_ids'] = invoice_lines
            new_invoice = request.env['account.move'].sudo().create(invoice_data)
            return {
                'status': 200,
                'message': 'Invoice created successfully',
                'invoice_id': new_invoice.id
            }
        except Exception as e:
            raise UserError(f"Failed to create invoice: {e}")

    @http.route('/update/invoice', type='json', auth='user')
    def update_invoice(self, **kwargs):
        invoice_id = kwargs.get('invoice_id')
        invoice = request.env['account.move'].sudo().browse(invoice_id)
        invoice_data = {
            'partner_id': kwargs.get('partner_id'),
            'invoice_date': kwargs.get('invoice_date'),
        }
        invoice_lines = []
        try:
            for line in kwargs.get('invoice_lines', []):
                invoice_lines.append((0, 0, {
                    'product_id': line.get('product_id'),
                    'quantity': line.get('unit_amount'),
                    'price_unit': line.get('product_charge'),
                    'subtotal': line.get('subtotal'),

                }))
            invoice_data['invoice_line_ids'] = invoice_lines
            invoice.write(invoice_data)
            return {
                'status': 200,
                'message': 'Invoice updated successfully',
                'invoice_id': invoice.id
            }
        except Exception as e:
            raise UserError(f"Failed to update invoice: {e}")

    @http.route('/delete/invoice', type='json', auth='user')
    def delete_invoice(self, **kwargs):
        invoice_id = kwargs.get('invoice_id')
        invoice = request.env['account.move'].sudo().browse(invoice_id)

        try:
            invoice.unlink()
            return {'status': 200, 'message': 'Invoice deleted successfully'}
        except Exception as e:
            raise UserError(f"Failed to delete invoice: {e}")














    # @http.route(route='/read/customer', type='json', auth='user')
    # def read_partners(self, **kwargs):
    #     user = request.env.user
    #     partners_sheet = request.env['res.partner'].sudo().search([])
    #     partners_data = []
    #     for partners in partners_sheet:
    #         data = {
    #             'id': partners.id,
    #             'name': partners.name,
    #             'street': partners.street,
    #             'street2': partners.street2,
    #             'city': partners.city,
    #             'state_id': partners.state_id.id,
    #             'zip': partners.zip,
    #             'phone': partners.phone,
    #             'mobile': partners.mobile,
    #             'website': partners.website,
    #             'title': partners.title,
    #             # 'category_id': partners.category_id.id,
    #         }
    #         partners_data.append(data)
    #     response = {'status': 200, 'response': partners_data, 'message': 'Success'}
    #     return (response

    # @http.route(route='/create/customer', type='json', methods=['POST'], auth='user')
    # def create_customer(self, **kwargs):
    #     create_customer = request.env['res.partner'].search([('is_company','=', True)])
    #     name = kwargs.get('name')
    #     company_id = kwargs.get('company_id')
    #     street = kwargs.get('street')
    #     street2 = kwargs.get('street2')
    #     city = kwargs.get('city')
    #     # zip = kwargs.get('zip')
    #     phone = kwargs.get('phone')
    #     mobile = kwargs.get('mobile')
    #     website = kwargs.get('website')
    #     title = kwargs.get('title')
    #     try:
    #         # Creating a new customer
    #         new_customer = create_customer.sudo().create({
    #             'name': name,
    #             'company_id': company_id,
    #             'street': street,
    #             'street2': street2,
    #             'city': city,
    #             # 'zip': zip,
    #             'phone': phone,
    #             'mobile': mobile,
    #             'website': website,
    #             'title': title,
    #         })
    #         return {'success': True, 'message': 'Record created successfully'}
    #     except exceptions.UserError as e:
    #         return ({'success': False, 'message': str(e)}
