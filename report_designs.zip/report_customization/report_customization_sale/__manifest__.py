{
    'name': 'Report Customization',
    'version': '17.0',

    "author": "Rao Mubasher Hussain",
    "website": """www.outsetx.com""",
    'company': '',
    'maintainer': 'Rao Mubasher Hussain',

    'depends': ['base', 'sale', 'account'],
    'license': 'LGPL-3',
    'category': 'Productivity',

    'summary': """ Report Customization, Add background/cover image """,
    'description': """ Report Customization, Add background/cover image """,

    'data': [

        'report/external_layout_boxed.xml',
        'report/sale_order_template.xml',
        'report/reports.xml',
        'report/invoice_template_inherit.xml',

    ],

    'installable': True,
    'application': True,
    'auto_install': False,
    'images': ['static/description/image/eco_ng_header.png'],

}
